// Basic drag‑and‑drop builder logic
$(function () {
  const basePrice = 65;
  // Track cart count
  let cartCount = 0;

  /**
   * Update the visible cart count indicator.
   */
  function updateCartDisplay() {
    $('#cart-count').text(cartCount);
  }

  /**
   * Recalculate and update the displayed total price.
   */
  function updatePrice() {
    let sum = basePrice;
    // Add $10 for back clasp option
    const claspVal = $('input[name="clasp"]:checked').val();
    if (claspVal === 'back') {
      sum += 10;
    }
    // Sum up prices for each dropped item
    $('#dropzone .dropped-item').each(function () {
      const price = parseFloat($(this).data('price'));
      if (!isNaN(price)) {
        sum += price;
      }
    });
    // Update the displayed price
    $('#total-price').text(sum.toFixed(2));
    // Enable or disable the Add to Cart button based on whether there are items
    if ($('#dropzone .dropped-item').length > 0) {
      $('#add-to-cart').prop('disabled', false);
    } else {
      $('#add-to-cart').prop('disabled', true);
    }
  }

  // Initialize the price display
  updatePrice();
  // Initialize cart display
  updateCartDisplay();

  // Set up dragstart for palette items
  const paletteItems = $('.palette-item');
  paletteItems.each(function (index) {
    this.addEventListener('dragstart', function (e) {
      // Save the index of the dragged element so we can clone it later
      e.dataTransfer.setData('text/plain', index.toString());
    });
  });

  // Get reference to the drop zone
  const dropZone = document.getElementById('dropzone');
  // Allow dropping by preventing the default behaviour
  dropZone.addEventListener('dragover', function (e) {
    e.preventDefault();
  });
  dropZone.addEventListener('drop', function (e) {
    e.preventDefault();
    const index = e.dataTransfer.getData('text/plain');
    const original = paletteItems.get(parseInt(index, 10));
    if (!original) return;
    // Clone the dragged element for the drop zone
    const $clone = $(original).clone();
    $clone.removeClass('palette-item').addClass('dropped-item');
    $clone.attr('draggable', false);
    // Remove placeholder text on first drop
    $('#dropzone .placeholder').remove();
    $('#dropzone').append($clone);
    updatePrice();
  });

  // Remove dropped items on click (acts like double click for simplicity)
  $('#dropzone').on('click', '.dropped-item', function () {
    $(this).remove();
    // Show placeholder if no items remain
    if ($('#dropzone .dropped-item').length === 0) {
      $('#dropzone').append('<p class="placeholder">Drag items here to design your necklace</p>');
    }
    updatePrice();
  });

  // Update price when clasp radio buttons change
  $('input[name="clasp"]').on('change', function () {
    updatePrice();
  });

  /**
   * Add an item to the cart and update the count.
   * @param {string} name Product name
   * @param {number} price Product price
   */
  function addToCart(name, price) {
    cartCount += 1;
    updateCartDisplay();
    // Simple feedback for demonstration
    alert(name + ' added to cart for $' + price.toFixed(2));
  }

  // Click handlers for static product cards
  $('.add-cart-btn').on('click', function () {
    const name = $(this).data('name');
    const price = parseFloat($(this).data('price'));
    addToCart(name, price);
  });

  // Handle adding custom necklace to cart
  $('#builder-form').on('submit', function (e) {
    e.preventDefault();
    // Only add if there is at least one dropped item
    if ($('#dropzone .dropped-item').length > 0) {
      // Calculate final price
      const total = parseFloat($('#total-price').text());
      addToCart('Custom Necklace', total);
      // Reset builder for new build
      $('#dropzone .dropped-item').remove();
      $('#dropzone').append('<p class="placeholder">Drag items here to design your necklace</p>');
      $('input[name="clasp"][value="front"]').prop('checked', true);
      updatePrice();
    } else {
      alert('Please add at least one bead or charm to your custom necklace.');
    }
  });
});